# VECTOR

Bac à sable spatial solo pour PC, en lignes vectorielles. Tout est écrit en Rust avec un moteur maison : rasteriseur de lignes sur CPU, police bitmap, simulation déterministe à pas fixe (30 Hz), galaxie infinie générée par fonction de hachage de la graine.

## Lancer
- Windows : lancer `vector-game.exe` depuis le dossier du jeu (le dossier `data/` doit se trouver à côté, ou dans un dossier parent).
- Depuis les sources : `cargo run --release -p vector-game`.

## Jouer en 2 minutes
1. **Nouvelle partie** (taper une graine avant de valider si vous voulez une galaxie précise). Le tutoriel guidé démarre ; `F10` l'ignore.
2. Pilotage : `W/S` tangage, `A/D` lacet, `Q/E` roulis, `Espace` poussée, `F` assistance de vol. `Tab`/`T`/`Y` ciblent, `G` lance le pilote automatique, `D` amarre près d'une station.
3. À quai : `Haut/Bas` choisit une ressource, `Entrée` vend, `B` achète, `F` fait le plein, `R` répare.
4. Minez un astéroïde (`T`, puis `V` maintenu à moins de 2 km), vendez, achetez de meilleurs modules (`H`) ou une autre coque (`Y`).
5. `L` ouvre la carte de la galaxie (saut FTL), `F2` l'empire (colonies), `F3` la flotte déléguée, `F4` les technologies, `F6` le codex, `F1` l'aide de l'écran courant, `Échap` le menu.

Toutes les touches : [docs/CONTROLS.md](docs/CONTROLS.md).

## Ce que contient le jeu
- Système solaire complet à orbites képlériennes, gravité et référentiels, pilote automatique brachistochrone, accélération du temps jusqu'à ×100 000.
- Vaisseau modulaire (74 modules, 21 armes et défenses, 15 coques) : bus d'énergie avec délestage, chaleur, radiateurs, santé par module.
- Équipage simulé (besoins, maladies, 155 événements, journal), économie vivante pilotée par les stocks (le trafic PNJ agit sur les mêmes marchés que vous), factions, réputation, douane, contrats émergents, banque.
- Galaxie infinie par secteurs, sauts FTL, scan progressif, anomalies, éruptions, météoroïdes.
- Colonies (32 bâtiments, 106 recettes), flotte déléguée avec routes, combat (faisceaux, balistique, missiles, mines, abordage, assurance), arbre de 73 technologies.
- Règles de partie (13 options) pour jouer en bac à sable, codex généré depuis les données, tutoriel, aide contextuelle, audio procédural, options graphiques (CRT, halo, palettes).

## Données et modding
Tout le contenu est dans `data/*.ron` (ressources, modules, coques, recettes, bâtiments, technologies, factions, événements, textes...). Modifier un fichier suffit : le chargement valide les références croisées, les masses des recettes et les graphes de technologies et refuse un fichier incohérent avec un message clair. Les fichiers `*_extra.ron` sont générés par `tools/*.py` (voir [docs/CONTENT.md](docs/CONTENT.md)).

## Outils
```
cargo run --release -p vector-tools --bin data_check      # valide les données et les seuils de contenu
cargo run --release -p vector-tools --bin sim_bench 1 10 100   # stabilité et vitesse sur 1/10/100 ans
cargo run --release -p vector-tools --bin balance_check   # rapport d'équilibrage de l'économie
vector-game --script scripts/first_flight.txt             # jeu scripté sans fenêtre
vector-game --snapshot image.png cockpit                  # rendu headless (PNG)
cargo test                                                 # toute la suite (≈ 200 tests)
```

## Architecture
| Crate | Rôle |
|---|---|
| `vector-core` | maths (Vec3, Mat3), RNG SplitMix64, hachage de coordonnées |
| `vector-render` | framebuffer, lignes avec découpage, police 5x7, caméra, PNG |
| `vector-world` | génération procédurale : étoiles, planètes, orbites, galaxie |
| `vector-data` | chargement et validation des `.ron` |
| `vector-sim` | simulation : vol, vaisseau, équipage, économie, colonies, combat, science, sauvegarde |
| `vector-game` | fenêtre, écrans, HUD, console, audio, tutoriel, mode script |
| `vector-tools` | `data_check`, `sim_bench`, `balance_check` |

Voir aussi [docs/SIM_MODEL.md](docs/SIM_MODEL.md) (modèle de simulation), [docs/DECISIONS.md](docs/DECISIONS.md) et [docs/PROGRESS.md](docs/PROGRESS.md).
